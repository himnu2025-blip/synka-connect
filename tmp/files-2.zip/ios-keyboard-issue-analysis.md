# iOS Browser Keyboard Issue - Analysis & Solutions

## Problem Summary
When the onscreen keyboard opens in iOS browsers, a **weird and unpredictable gap appears above the keyboard** for most fields. The last name field works fine, but other fields (role, company, etc.) show this gap.

## Root Cause Analysis

### 1. **Fixed Positioning with transform: translate(-50%, -50%)**
**Location:** `src/components/ui/dialog.tsx` line 42-43

```tsx
className="fixed left-[50%] top-[50%] z-50 ... translate-x-[-50%] translate-y-[-50%]"
```

**Problem:** 
- iOS Safari recalculates viewport height when the keyboard opens
- The dialog remains fixed at `top-[50%]` which is calculated from the ORIGINAL viewport height
- When viewport shrinks due to keyboard, the `translate-y-[-50%]` doesn't account for the new viewport
- This creates a gap because the dialog center point is now ABOVE the visible area

**Why Last Name Works:**
- Last Name is the LAST field in the FloatingNameInput (line 1269-1277 in MyCard.tsx)
- When it's focused, iOS scrolls to show it, and the dialog happens to align correctly
- Other fields trigger scrolling but the fixed position causes misalignment

### 2. **iOS-Specific Viewport Issues**
**Location:** `src/index.css` lines 189-199

```css
/* Current - tries to handle dynamic viewport */
[data-vaul-drawer] {
  height: 100dvh;
}

@supports (-webkit-touch-callout: none) {
  [data-vaul-drawer] {
    height: -webkit-fill-available;
  }
}
```

**Problem:**
- This only applies to `[data-vaul-drawer]` (Drawer component)
- Dialogs don't get this treatment
- iOS keyboard changes viewport dynamically but fixed elements don't adapt

### 3. **Scroll Behavior Conflicts**
**Location:** `src/index.css` lines 215-220

```css
input:focus, 
textarea:focus, 
select:focus {
  scroll-margin-block: 1rem;
}
```

**Problem:**
- When combined with fixed positioning, iOS tries to scroll the input into view
- But the parent dialog is fixed, so it creates competing scroll behaviors
- Results in unpredictable gaps

## Solutions

### ✅ Solution 1: Use Absolute Positioning Instead of Fixed (RECOMMENDED)

**File:** `src/components/ui/dialog.tsx`

Replace the DialogContent className (line 42-44):

```tsx
// BEFORE
className={cn(
  "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg",
  className,
)}

// AFTER
className={cn(
  "fixed inset-x-4 top-[10%] z-50 grid w-auto max-w-lg mx-auto gap-4 border bg-background p-6 shadow-lg duration-200 max-h-[85vh] overflow-y-auto data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg",
  className,
)}
```

**Changes:**
- Remove `left-[50%] translate-x-[-50%] translate-y-[-50%]`
- Use `inset-x-4` for horizontal positioning with margins
- Use `top-[10%]` instead of `top-[50%]` - stays near top
- Add `mx-auto` for centering
- Add `max-h-[85vh] overflow-y-auto` for scroll within dialog
- Remove slide-out/in animations that rely on translate

### ✅ Solution 2: Add iOS-Specific Viewport Adjustments

**File:** `src/index.css`

Add after line 223 (in @layer components section):

```css
/* iOS keyboard viewport fix for dialogs */
@supports (-webkit-touch-callout: none) {
  /* Dialog positioned from top instead of center on iOS */
  [data-radix-dialog-content] {
    top: max(10%, env(safe-area-inset-top, 0px)) !important;
    transform: translateX(-50%) !important;
    max-height: calc(90vh - env(safe-area-inset-bottom, 0px));
    overflow-y: auto;
  }
}
```

This ensures:
- Dialog stays near the top of viewport
- Accounts for safe areas (notch)
- Allows scrolling within the dialog
- Only affects iOS devices

### ✅ Solution 3: Enhanced Input Focus Handling

**File:** `src/components/ui/floating-input.tsx`

Add focus handling to FloatingInput (lines 84-114):

```tsx
export const FloatingInput = ({
  label,
  value,
  onChange,
  type = 'text',
  inputMode,
  disabled,
  className,
  inputRef,
  onFocus,
  onBlur,
}: FloatingInputProps) => {
  // Add this handler
  const handleFocus = (e: React.FocusEvent<HTMLInputElement>) => {
    // Small delay to let iOS keyboard settle
    setTimeout(() => {
      e.target.scrollIntoView({ 
        behavior: 'smooth', 
        block: 'center',
        inline: 'nearest' 
      });
    }, 300);
    onFocus?.(e);
  };

  return (
    <div className={cn("relative h-14", className)}>
      <input
        ref={inputRef}
        type={type}
        inputMode={inputMode}
        value={value}
        onChange={onChange}
        onFocus={handleFocus}  // Changed
        onBlur={onBlur}
        // ... rest of props
```

Do the same for `FloatingPhoneInput` at lines 183-252.

### ✅ Solution 4: Add Viewport Meta Tag Safety

**File:** `index.html`

Ensure you have proper viewport meta (should already exist):

```html
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
```

Add if missing:
- `viewport-fit=cover` - handles notch areas
- `maximum-scale=1` - prevents zoom on input focus

## Testing Recommendations

### On iOS Safari:
1. Open the edit dialog
2. Test each field in sequence:
   - First Name ✓
   - Last Name ✓ (already working)
   - Role/Designation
   - Company Name
   - Email
   - Phone
   - WhatsApp
3. Verify no gap appears above keyboard
4. Verify dialog doesn't jump or resize unexpectedly
5. Test in both portrait and landscape

### Edge Cases to Test:
- Very long company names
- Switching between fields quickly
- Rotating device while keyboard is open
- Fields near bottom of dialog

## Priority Implementation Order

1. **Solution 1** (Dialog positioning) - HIGHEST IMPACT
2. **Solution 2** (iOS CSS fixes) - COMPLEMENTS #1
3. **Solution 3** (Input focus handling) - POLISH
4. **Solution 4** (Meta tag) - VERIFY ONLY

## Technical Explanation: Why This Happens

### iOS Viewport Behavior:
1. **Initial state:** viewport = 100vh (e.g., 844px on iPhone)
2. **Keyboard opens:** viewport shrinks to ~400-500px
3. **Fixed elements:** Still reference original 100vh
4. **Result:** 
   - `top: 50%` = 422px (half of 844px)
   - Visible viewport = 0-500px
   - Dialog center is ABOVE visible area (422px > 250px midpoint)
   - Gap appears above keyboard

### Why translate(-50%, -50%) Fails:
- `translate-y-[-50%]` is calculated from element's own height
- Doesn't account for viewport changes
- Creates offset that positions dialog incorrectly

### Why top-based positioning works:
- `top: 10%` = Always 10% from viewport top
- Even when viewport shrinks, still 10% from new top
- No transform calculations needed
- Dialog stays visible and properly positioned

## Additional Notes

- Android works fine because it doesn't resize the viewport (uses overlay)
- The "flicker" on role/company is likely the scroll adjustment happening
- This is a known iOS Safari issue affecting many web apps
- Solutions focus on avoiding viewport percentage positioning during keyboard events

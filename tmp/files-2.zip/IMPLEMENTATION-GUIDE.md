# iOS Keyboard Fix - Implementation Guide

## Quick Start (3 Simple Steps)

### Step 1: Fix Dialog Component ⭐ MOST IMPORTANT
**File:** `src/components/ui/dialog.tsx`

**Replace line 42-44** (the DialogContent className):

**OLD CODE:**
```tsx
className={cn(
  "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg",
  className,
)}
```

**NEW CODE:**
```tsx
className={cn(
  "fixed inset-x-4 top-[10%] z-50 grid w-auto max-w-lg mx-auto gap-4 border bg-background p-6 shadow-lg duration-200 max-h-[85vh] overflow-y-auto data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg",
  className,
)}
```

**What changed:**
- ❌ Removed: `left-[50%] top-[50%] translate-x-[-50%] translate-y-[-50%]`
- ✅ Added: `inset-x-4 top-[10%] mx-auto max-h-[85vh] overflow-y-auto`
- ✅ Removed problematic slide animations

---

### Step 2: Add iOS CSS Fixes
**File:** `src/index.css`

**Add at the end of the file (after line 548):**

```css
/* iOS keyboard viewport fix for dialogs */
@supports (-webkit-touch-callout: none) {
  [data-radix-dialog-content] {
    top: max(10%, env(safe-area-inset-top, 0px)) !important;
    transform: translateX(0) !important;
    max-height: calc(90vh - env(safe-area-inset-bottom, 0px));
    overflow-y: auto;
    -webkit-overflow-scrolling: touch;
  }
  
  [data-radix-dialog-content] > div {
    max-height: 100%;
  }
}

@media (max-width: 768px) {
  [data-radix-dialog-content] {
    max-width: calc(100vw - 2rem);
    overscroll-behavior: contain;
  }
  
  body:has([data-radix-dialog-content]) {
    overflow: hidden;
    position: fixed;
    width: 100%;
  }
}
```

---

### Step 3: Enhanced Input Focus (Optional but Recommended)
**File:** `src/components/ui/floating-input.tsx`

**In FloatingInput component, update the onFocus handler:**

Find line ~73 where FloatingInput is defined, and add this handler before the return statement:

```tsx
export const FloatingInput = ({
  label,
  value,
  onChange,
  type = 'text',
  inputMode,
  disabled,
  className,
  inputRef,
  onFocus,
  onBlur,
}: FloatingInputProps) => {
  // ✅ ADD THIS: iOS FIX for smooth scroll
  const handleFocus = (e: React.FocusEvent<HTMLInputElement>) => {
    onFocus?.(e);
    
    if (/iPhone|iPad|iPod/.test(navigator.userAgent)) {
      setTimeout(() => {
        e.target.scrollIntoView({ 
          behavior: 'smooth', 
          block: 'center',
          inline: 'nearest' 
        });
      }, 300);
    }
  };

  return (
    <div className={cn("relative h-14", className)}>
      <input
        ref={inputRef}
        type={type}
        inputMode={inputMode}
        value={value}
        onChange={onChange}
        onFocus={handleFocus}  // ✅ CHANGE THIS from {onFocus} to {handleFocus}
        onBlur={onBlur}
        // ... rest stays the same
```

**Do the same for FloatingPhoneInput** (around line 185-195).

---

## Testing Checklist

After implementing, test on iOS Safari:

- [ ] First Name field - no gap
- [ ] Last Name field - no gap
- [ ] Role field - no gap ⭐ (was problematic)
- [ ] Company field - no gap ⭐ (was problematic)
- [ ] Email field - no gap
- [ ] Phone field - no gap
- [ ] WhatsApp field - no gap
- [ ] Dialog doesn't jump or resize
- [ ] Can scroll through all fields smoothly
- [ ] Keyboard close/open works smoothly

---

## Why This Works

### The Problem:
```
iOS Viewport: 100vh (844px)
Dialog at: top: 50% = 422px

Keyboard Opens:
iOS Viewport: 100vh shrinks to ~500px
Dialog STILL at: 422px (now above visible area!)
Result: Gap appears above keyboard
```

### The Solution:
```
Dialog at: top: 10% 
iOS Viewport: 100vh (844px)
Position: 84px from top

Keyboard Opens:
iOS Viewport: shrinks to ~500px  
Position: 50px from top (still 10%!)
Result: Dialog stays visible, no gap!
```

---

## Alternative: Quick Patch (If full fix causes issues)

If the full fix causes layout issues elsewhere, you can apply a **minimal patch** just for iOS:

**File:** `src/index.css`

Add just this:

```css
/* iOS-only quick fix */
@supports (-webkit-touch-callout: none) {
  @media (max-width: 768px) {
    [data-radix-dialog-content] {
      top: 5vh !important;
      bottom: auto !important;
      transform: translateX(-50%) !important;
      max-height: 90vh;
      overflow-y: auto;
    }
  }
}
```

This is less comprehensive but should fix the immediate gap issue.

---

## Files Provided

1. `ios-keyboard-issue-analysis.md` - Full technical analysis
2. `dialog-FIXED.tsx` - Complete fixed dialog component
3. `floating-input-FIXED.tsx` - Complete fixed input component  
4. `css-additions-for-ios-fix.css` - CSS to add to index.css
5. `IMPLEMENTATION-GUIDE.md` - This file

## Need Help?

If issues persist:
1. Check browser console for errors
2. Verify you're testing on actual iOS Safari (not Chrome on iOS)
3. Try testing in both portrait and landscape
4. Check if viewport meta tag is correct in index.html
